<?php
header('Content-Type: application/json');

$identifier = filter_input(INPUT_POST, 'identifier', FILTER_SANITIZE_STRING);

if (!$identifier) {
    echo json_encode(['success' => false, 'message' => 'Identificador inválido']);
    exit;
}

$ch = curl_init('https://api.risepay.com.br/api/External/Transactions/' . $identifier);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: 453f5abb6917c46908be6546928780521242706204134affc940b3fd19a90d3b'
]);

$response = curl_exec($ch);
curl_close($ch);

echo $response;
?>