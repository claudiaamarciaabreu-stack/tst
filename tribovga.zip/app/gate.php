<?php
header('Content-Type: application/json');

$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$cpf = filter_input(INPUT_POST, 'cpf', FILTER_SANITIZE_STRING);
$phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
$cpf = preg_replace('/[^0-9]/', '', $cpf);

if (!$name || !$email || !$cpf || !$phone || strlen($cpf) !== 11) {
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit;
}

$data = [
    'amount' => 105.08,
    'payment' => ['method' => 'pix'],
    'customer' => [
        'name' => $name,
        'email' => $email,
        'cpf' => $cpf,
        'phone' => $phone
    ]
];

$ch = curl_init('https://api.risepay.com.br/api/External/Transactions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: 453f5abb6917c46908be6546928780521242706204134affc940b3fd19a90d3b'
]);

$response = curl_exec($ch);
curl_close($ch);

setcookie('pix_response', $response, time() + 3600, '/');

echo $response;
?>